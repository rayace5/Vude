package Window.common;

public class Users {

	public class Person {
		private String firstName;

		//////////////////////////////////////////////////////////////////////
		// Constructors

		public Person(String fName) {
			firstName = fName;

		}

		//////////////////////////////////////////////////////////////////////
		// Getters/Setters
		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String fName) {
			firstName = fName;

		}
	}

}
